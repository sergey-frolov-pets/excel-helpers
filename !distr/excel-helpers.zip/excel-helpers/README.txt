# excel-helpers 
version 0.6

What's new:
- add 'sfUpdateTableRecords.xlsm' - Update table records tool + example folder for it

Excel tools and VBA snippets for focused business tasks

Contains:
sfDecisionMaking.xlsx - Decision maker tool
sfDynamicGANTT.xlsx - Dynamic GANTT tool
sfFriendlySpam.xlsm - Friendly spam sender tool
sfHistogramMaker.xlsx - Histogram maker tool
sfMultiValueCells.xlsm - Multivalue cells macro 
sfUpdateTableRecords.xlsm - Update table records tool
sfSnippets.xlsm - VBA snippets which help to develop your personal VBA-tools 
sfVBAXMLCommentsToGitHubWiki.xlsm - Tool for generating Github markdown wiki-pages from VBA modules which contain XML comments
See "HowTo" sheet inside each file for instructions

Have a questions or looking for others Excel tools? 
Visit: https://github.com/sergey-frolov-pets/excel-helpers

